var player=[];
var mark=["X","O"];
var turn=0;
var scores=[0,0];
player[0]="Player1";
player[1]="Player2";
var winvalues=[7,56,73,84,146,273,292,448];
var gameover=false;

function count(upoints)
{
	scores[turn] +=  upoints;
}
function wintest()
{
	console.log(scores[0]+ " "+ scores[1]);
	for(var i=0;i<winvalues.length;i++)
	{
		if((winvalues[i] & scores[turn])==winvalues[i])
		{
			gameover=true;
			document.getElementById("game-message").innerText=player[turn]+" Wins";
		}
	}
	if(((scores[0]+scores[1])==511) && !gameover)
	{
		document.getElementById("game-message").innerText="No One Wins";
		console.log(document.getElementById("game-message").innerText);
		gameover=true;
	}
}
//Play Game
function play_game(onclicked,divPoints)
{
	if(!gameover)
	{
		if(onclicked.innerHTML=="&nbsp;")
		{
			count(divPoints);
			//onclicked.onclick="";//to remove this after on click
			onclicked.innerHTML="<span>"+ mark[turn] +"</span>";//not text now but html
			wintest();
			if(!gameover) {shuffle_turn();}
		}
	}
}
function shuffle_turn()
{
	if(turn==0) turn=1;
	else turn=0;
	document.getElementById("game-message").innerText=player[turn]+ " 's Turn!";
}